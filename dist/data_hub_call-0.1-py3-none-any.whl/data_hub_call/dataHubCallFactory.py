# Polymorphic factory methods.
from __future__ import generators
from dataHubCallTriangulum import DataHubCallTriangulum
from dataHubCallCityVervePoP import DataHubCallCityVervePoP
from dataHubCallBTHub import DataHubCallBTHub

class DataHubCallFactory:
    factories = {}

    def add_factory(id, data_hub_call_factory):
        DataHubCallFactory.factories.put[id] = data_hub_call_factory
    add_factory = staticmethod(add_factory)

    # A Template Method:
    def create_data_hub_call(request):
        if request.hub_call_classname not in DataHubCallFactory.factories:
            DataHubCallFactory.factories[request.hub_call_classname] = eval(request.hub_call_classname + '.Factory()')
        return DataHubCallFactory.factories[request.hub_call_classname].create(request)

    create_data_hub_call = staticmethod(create_data_hub_call)